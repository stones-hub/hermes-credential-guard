"""Target ↔ credential binding (no permission fields)."""

from __future__ import annotations

from typing import Any, Dict

from .file_backend import FileBackendError, FileCredentialBackend


class TargetBindingError(Exception):
    """Fail-closed binding error without secrets."""


def resolve_mysql_target(
    backend: FileCredentialBackend, target_id: str
) -> Dict[str, Any]:
    """Return target metadata bound to a mysql credential identity (no secret)."""
    try:
        target = backend.get_target(target_id)
    except FileBackendError as exc:
        raise TargetBindingError("unknown or invalid target") from exc
    if target.get("type") != "mysql":
        raise TargetBindingError("target type mismatch")
    cred_id = target["credential_ref"]
    try:
        meta = {
            item["id"]: item for item in backend.list_credential_metadata()
        }
    except FileBackendError as exc:
        raise TargetBindingError("credential backend unavailable") from exc
    cred = meta.get(cred_id)
    if cred is None:
        raise TargetBindingError("credential_ref not found")
    if cred.get("type") != "mysql":
        raise TargetBindingError("credential type mismatch")
    return {
        "target_id": target["id"],
        "type": "mysql",
        "host": target["host"],
        "port": target["port"],
        "database": target["database"],
        "credential_id": cred_id,
        "username": cred["username"],
    }
