from __future__ import annotations

from .registry import CredentialRegistry

_registry = CredentialRegistry()


def get_registry() -> CredentialRegistry:
    """Process-local base registry (tests may register synthetic canaries)."""
    return _registry


def get_egress_registry_snapshot() -> CredentialRegistry:
    """Fresh independent merge of base memory registry + file secret store.

    Never mutates the shared global registry in place. Conflicts (same identity
    with different secret, or same secret under multiple identities) fail closed.
    File-store read/schema/permission failures also fail closed.
    """
    from .file_backend import FileBackendError, build_redaction_registry_snapshot

    file_snap = build_redaction_registry_snapshot()
    merged = CredentialRegistry()
    try:
        for item in _registry.values():
            merged.register(item.key, item.field, item.secret)
        for item in file_snap.values():
            merged.register(item.key, item.field, item.secret)
    except ValueError as exc:
        raise FileBackendError("egress registry merge conflict") from exc
    except FileBackendError:
        raise
    except Exception as exc:
        raise FileBackendError("egress registry merge failed") from exc
    return merged
