"""pre_tool_call: approval for credential tools + sensitive-path blocks."""

from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any, Dict, Optional

from .sensitive_paths import (
    args_target_protected,
    terminal_command_reads_protected,
)
from .tools import TOOL_NAME as MYSQL_TOOL_NAME
from .tools import default_store_dir

SSH_TOOL_NAME = "ssh_credential_action"
_CREDENTIAL_TOOLS = frozenset({MYSQL_TOOL_NAME, SSH_TOOL_NAME})

_SAFE_BLOCK = {
    "action": "block",
    "message": "credential-guard blocked access to a protected local path",
}


def _normalize_args(args: Dict[str, Any]) -> Dict[str, Any]:
    target = args.get("target") if isinstance(args.get("target"), str) else ""
    action = args.get("action") if isinstance(args.get("action"), str) else ""
    return {"target": target, "action": action}


def _args_digest(args: Dict[str, Any]) -> str:
    payload = json.dumps(_normalize_args(args), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def _approval_rule_key(tool_name: str, args: Dict[str, Any], tool_call_id: str = "") -> str:
    """Per-call allowlist grain: high-entropy nonce + normalized arg digest."""
    nonce = secrets.token_hex(16)
    digest = _args_digest(args)
    _ = tool_call_id
    return f"{tool_name}:n:{nonce}:a:{digest}"


def _mysql_approval_message(args: Dict[str, Any]) -> str:
    target = args.get("target")
    action = args.get("action")
    target_s = target if isinstance(target, str) and target else "<unknown>"
    action_s = action if isinstance(action, str) and action else "<unknown>"
    cred_id = "<unknown>"
    database = "<unknown>"
    if isinstance(target, str) and target:
        try:
            from .file_backend import TargetMetadataBackend

            backend = TargetMetadataBackend(default_store_dir())
            meta = backend.get_target(target)
            database = str(meta.get("database") or "<unknown>")
            cred_id = str(meta.get("credential_ref") or "<unknown>")
        except Exception:
            pass
    return (
        f"credential-guard requires approval for {MYSQL_TOOL_NAME}: "
        f"target={target_s} action={action_s} "
        f"credential={cred_id} database={database}"
    )


def _ssh_approval_message(args: Dict[str, Any]) -> str:
    """Approval text: business target + action + type; never SSH alias."""
    target = args.get("target")
    action = args.get("action")
    target_s = target if isinstance(target, str) and target else "<unknown>"
    action_s = action if isinstance(action, str) and action else "<unknown>"
    # Read targets.json only — never credentials.json, never start SSH.
    if isinstance(target, str) and target:
        try:
            from .file_backend import TargetMetadataBackend

            backend = TargetMetadataBackend(default_store_dir())
            meta = backend.get_target(target)
            if meta.get("type") != "ssh_config":
                # Still escalate; handler will reject type mismatch.
                pass
        except Exception:
            pass
    return (
        f"credential-guard requires approval for {SSH_TOOL_NAME}: "
        f"target={target_s} action={action_s} "
        f"type=SSH auth=local-SSH-Config"
    )


def _scrub_message(message: str, tool_name: str, payload: Dict[str, Any]) -> str:
    if "password" in message.lower() or "://" in message or "/" in message:
        target = payload.get("target")
        action = payload.get("action")
        target_s = target if isinstance(target, str) and target else "<unknown>"
        action_s = action if isinstance(action, str) and action else "<unknown>"
        return (
            f"credential-guard requires approval for {tool_name}: "
            f"target={target_s} action={action_s}"
        )
    return message


def _block_sensitive_path(tool_name: str, args: Dict[str, Any]) -> Optional[Dict[str, str]]:
    name = (tool_name or "").strip()
    if name in ("read_file", "search_files"):
        if args_target_protected(name, args):
            return dict(_SAFE_BLOCK)
        return None
    if name in ("terminal", "execute_code", "run_terminal_command"):
        command = ""
        if isinstance(args.get("command"), str):
            command = args["command"]
        elif isinstance(args.get("code"), str):
            command = args["code"]
        if command and terminal_command_reads_protected(command):
            return dict(_SAFE_BLOCK)
        return None
    return None


def on_pre_tool_call(
    tool_name: str = "",
    args: Optional[Dict[str, Any]] = None,
    tool_call_id: str = "",
    **_kwargs: Any,
) -> Optional[Dict[str, str]]:
    """Sensitive-path block, or escalate credential tools to Hermes approval."""
    try:
        payload = args if isinstance(args, dict) else {}
        blocked = _block_sensitive_path(tool_name, payload)
        if blocked is not None:
            return blocked

        if tool_name not in _CREDENTIAL_TOOLS:
            return None

        if tool_name == SSH_TOOL_NAME:
            message = _ssh_approval_message(payload)
        else:
            message = _mysql_approval_message(payload)
        message = _scrub_message(message, tool_name, payload)
        return {
            "action": "approve",
            "message": message,
            "rule_key": _approval_rule_key(tool_name, payload, tool_call_id),
        }
    except Exception:
        if tool_name in _CREDENTIAL_TOOLS:
            return {
                "action": "approve",
                "message": f"credential-guard requires approval for {tool_name}",
                "rule_key": _approval_rule_key(
                    tool_name,
                    args if isinstance(args, dict) else {},
                    tool_call_id,
                ),
            }
        return dict(_SAFE_BLOCK)
