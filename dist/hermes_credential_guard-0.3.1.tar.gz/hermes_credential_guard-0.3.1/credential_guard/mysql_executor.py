"""Fixed MySQL read-only actions via plugin-vendored MySQL SDK."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

_ALLOWED = frozenset({"check_connection", "show_effective_grants"})
_PINNED_PYMYSQL_VERSION = "1.2.0"

# High-risk grant fragments that must not reach the model.
_GRANT_DENY_RE = re.compile(
    r"(IDENTIFIED\s+BY|AUTHENTICATION_STRING|AS\s+'|PASSWORD\s*\(|mysql_native_password|caching_sha2_password)",
    re.IGNORECASE,
)


class MySQLExecutorError(Exception):
    def __init__(self, error_code: str) -> None:
        super().__init__(error_code)
        self.error_code = error_code


def _plugin_deps_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "deps"


def _ensure_pymysql():
    """Import pinned PyMySQL strictly from this plugin's deps/ tree.

    Never prefers an arbitrary host site-packages copy. Fail loud on missing,
    wrong path, or version mismatch.
    """
    deps = _plugin_deps_dir()
    if not deps.is_dir():
        raise MySQLExecutorError("sdk_unavailable")
    deps_s = str(deps)
    # Force plugin deps ahead of any host pymysql already imported / on path.
    while deps_s in sys.path:
        sys.path.remove(deps_s)
    sys.path.insert(0, deps_s)
    # Drop a previously imported non-vendored pymysql so re-import resolves here.
    existing = sys.modules.get("pymysql")
    if existing is not None:
        existing_file = getattr(existing, "__file__", "") or ""
        try:
            existing_path = Path(existing_file).resolve()
            if deps.resolve() not in existing_path.parents and existing_path != deps.resolve():
                for key in list(sys.modules):
                    if key == "pymysql" or key.startswith("pymysql."):
                        del sys.modules[key]
        except Exception:
            for key in list(sys.modules):
                if key == "pymysql" or key.startswith("pymysql."):
                    del sys.modules[key]
    try:
        import pymysql  # type: ignore
    except ImportError as exc:
        raise MySQLExecutorError("sdk_unavailable") from exc
    pymysql_file = getattr(pymysql, "__file__", "") or ""
    try:
        resolved = Path(pymysql_file).resolve()
    except Exception as exc:
        raise MySQLExecutorError("sdk_source_invalid") from exc
    deps_resolved = deps.resolve()
    if deps_resolved not in resolved.parents and resolved.parent != deps_resolved:
        raise MySQLExecutorError("sdk_source_invalid")
    version = getattr(pymysql, "VERSION_STRING", None) or getattr(
        pymysql, "__version__", None
    )
    if str(version) != _PINNED_PYMYSQL_VERSION:
        raise MySQLExecutorError("sdk_version_mismatch")
    return pymysql


def execute_action(
    *,
    action: str,
    host: str,
    port: int,
    database: str,
    username: str,
    password: str,
) -> Dict[str, Any]:
    if action not in _ALLOWED:
        return {"ok": False, "error_code": "invalid_action"}
    if host not in {"127.0.0.1", "localhost", "::1"}:
        return {"ok": False, "error_code": "host_not_allowed"}
    try:
        pymysql = _ensure_pymysql()
    except MySQLExecutorError as exc:
        return {"ok": False, "error_code": exc.error_code}

    conn = None
    try:
        conn = pymysql.connect(
            host=host,
            port=int(port),
            user=username,
            password=password,
            database=database,
            connect_timeout=5,
            read_timeout=5,
            write_timeout=5,
            charset="utf8mb4",
            autocommit=True,
        )
        if action == "check_connection":
            return _check_connection(conn)
        return _show_effective_grants(conn, password=password)
    except MySQLExecutorError as exc:
        return {"ok": False, "error_code": exc.error_code}
    except Exception as exc:
        # Map without leaking exception text (may contain auth details).
        name = type(exc).__name__
        if "OperationalError" in name or "InterfaceError" in name:
            # Wrong password vs unreachable — do not distinguish via raw msg.
            return {"ok": False, "error_code": "connection_failed"}
        return {"ok": False, "error_code": "executor_failed"}
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def _check_connection(conn: Any) -> Dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            "SELECT 1 AS ok, CURRENT_USER() AS account, "
            "DATABASE() AS database_name, VERSION() AS server_version"
        )
        row = cur.fetchone()
    if not row:
        raise MySQLExecutorError("query_failed")
    ok, account, database_name, server_version = row
    return {
        "ok": True,
        "authenticated": bool(ok),
        "account": str(account),
        "database_name": str(database_name) if database_name is not None else "",
        "server_version": str(server_version),
    }


def _show_effective_grants(conn: Any, *, password: str) -> Dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute("SHOW GRANTS FOR CURRENT_USER()")
        rows = cur.fetchall()
    grants: List[str] = []
    for row in rows or ():
        if not row:
            continue
        text = str(row[0])
        if password and password in text:
            raise MySQLExecutorError("secret_in_grants")
        if _GRANT_DENY_RE.search(text):
            raise MySQLExecutorError("unsafe_grant_text")
        grants.append(text)
    return {"ok": True, "grants": grants}
