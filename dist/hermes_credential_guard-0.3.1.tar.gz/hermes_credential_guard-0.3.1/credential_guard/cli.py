from __future__ import annotations

from typing import Any, Callable, Optional

from .state import get_egress_registry_snapshot, get_registry

INTERCEPT_POINTS = (
    "llm_request",
    "llm_execution",
    "transform_tool_result",
    "pre_tool_call",
)
PLUGIN_NAME = "credential-guard"
MYSQL_TOOL_NAME = "mysql_credential_action"
SSH_TOOL_NAME = "ssh_credential_action"
TOOL_NAMES = (MYSQL_TOOL_NAME, SSH_TOOL_NAME)
# Back-compat alias for older imports/tests.
TOOL_NAME = MYSQL_TOOL_NAME

# Expected leaf callback names inside the loaded plugin package.
_EXPECTED_CALLBACKS = {
    "llm_request": "on_llm_request",
    "llm_execution": "on_llm_execution",
    "transform_tool_result": "on_transform_tool_result",
    "pre_tool_call": "on_pre_tool_call",
}


def setup_parser(subparser: Any) -> None:
    subs = subparser.add_subparsers(dest="credential_guard_command")
    check = subs.add_parser("check", help="Check credential-guard registration")
    check.set_defaults(func=handle_command)


def handle_command(args: Any) -> int:
    if getattr(args, "credential_guard_command", "") != "check":
        print("usage: hermes credential-guard check")
        return 1
    return run_check()


def run_check() -> int:
    """Query the live PluginManager for intercept registration + registry health."""
    missing: list[str] = []
    try:
        from hermes_cli.plugins import get_plugin_manager

        mgr = get_plugin_manager()
    except Exception:
        print("credential-guard: check failed: PluginManager unavailable")
        return 1

    loaded = getattr(mgr, "_plugins", {}).get(PLUGIN_NAME)
    if loaded is None or not getattr(loaded, "enabled", False):
        missing.append("plugin_loaded_enabled")

    plugin_ns = _plugin_namespace(loaded)
    if loaded is not None and getattr(loaded, "enabled", False) and not plugin_ns:
        missing.append("plugin_module_namespace")

    middleware = getattr(mgr, "_middleware", {})
    hooks = getattr(mgr, "_hooks", {})

    req_cbs = list(middleware.get("llm_request", []) or [])
    exec_cbs = list(middleware.get("llm_execution", []) or [])
    tool_cbs = list(hooks.get("transform_tool_result", []) or [])
    pre_tool_cbs = list(hooks.get("pre_tool_call", []) or [])

    if not _has_our_callback(req_cbs, "llm_request", plugin_ns, loaded):
        missing.append("llm_request")
    if not _has_our_callback(exec_cbs, "llm_execution", plugin_ns, loaded):
        missing.append("llm_execution")
    if not _has_our_callback(tool_cbs, "transform_tool_result", plugin_ns, loaded):
        missing.append("transform_tool_result")
    if not _has_our_callback(pre_tool_cbs, "pre_tool_call", plugin_ns, loaded):
        missing.append("pre_tool_call")
    if not _has_our_tool(mgr, loaded, MYSQL_TOOL_NAME, "handle_mysql_credential_action",
                         (".credential_guard.tools", ".tools")):
        missing.append(MYSQL_TOOL_NAME)
    if not _has_our_tool(mgr, loaded, SSH_TOOL_NAME, "handle_ssh_credential_action",
                         (".credential_guard.ssh_tools", ".ssh_tools")):
        missing.append(SSH_TOOL_NAME)

    try:
        registry = get_registry()
        meta = registry.metadata()
        entry_count = len(meta)
    except Exception:
        missing.append("registry")
        entry_count = -1
        meta = []

    egress_status = "unavailable"
    egress_opaque_count = 0
    try:
        egress = get_egress_registry_snapshot()
        egress_opaque_count = len(egress.metadata())
        egress_status = "ready"
    except Exception:
        egress_status = "unavailable"
        egress_opaque_count = 0
        missing.append("egress_registry")

    if missing:
        print("credential-guard: check failed")
        print(f"missing: {', '.join(missing)}")
        print(f"egress_registry={egress_status}")
        print(f"egress_opaque_count={egress_opaque_count}")
        return 1

    print("credential-guard: enabled")
    print(f"intercepts: {', '.join(INTERCEPT_POINTS)}")
    print(f"tools: {', '.join(TOOL_NAMES)}")
    print(f"registry_entries: {entry_count}")
    print(f"egress_registry={egress_status}")
    print(f"egress_opaque_count={egress_opaque_count}")
    for item in meta:
        # key/field/token_id only — never secrets
        print(f"registry_meta: {item['key']}.{item['field']} -> {item['token_id']}")
    return 0


def _plugin_namespace(loaded: Any) -> str:
    if loaded is None:
        return ""
    module = getattr(loaded, "module", None)
    if module is None:
        return ""
    name = getattr(module, "__name__", "") or ""
    return name


def _expected_callable(loaded: Any, intercept: str) -> Optional[Callable[..., Any]]:
    """Resolve the live plugin's expected callback identity when importable."""
    import importlib
    import sys

    expected_name = _EXPECTED_CALLBACKS.get(intercept)
    if not expected_name or loaded is None:
        return None
    plugin_ns = _plugin_namespace(loaded)
    if not plugin_ns:
        return None
    if intercept == "transform_tool_result":
        rels = (".credential_guard.hooks", ".hooks")
    elif intercept == "pre_tool_call":
        rels = (".credential_guard.approval", ".approval")
    else:
        rels = (".credential_guard.middleware", ".middleware")
    for rel in rels:
        mod_name = plugin_ns + rel
        mod = sys.modules.get(mod_name)
        if mod is None:
            try:
                mod = importlib.import_module(mod_name)
            except Exception:
                continue
        cb = getattr(mod, expected_name, None)
        if callable(cb):
            return cb
    return None


def _has_our_callback(
    callbacks: list[Any],
    intercept: str,
    plugin_ns: str,
    loaded: Any,
) -> bool:
    """Accept only the production callback object directly registered in the manager.

    Does not match by bare function name or ``credential_guard`` substring.
    Does not trust arbitrary ``__wrapped__`` forgeries — the exact production
    callable identity must appear in the PluginManager callback list.
    """
    if not plugin_ns:
        return False
    expected_cb = _expected_callable(loaded, intercept)
    if expected_cb is None:
        return False
    for cb in callbacks:
        if cb is expected_cb:
            return True
    return False


def _resolve_handler(
    loaded: Any, handler_name: str, rels: tuple
) -> Optional[Callable[..., Any]]:
    import importlib
    import sys

    plugin_ns = _plugin_namespace(loaded)
    if not plugin_ns:
        return None
    for rel in rels:
        mod_name = plugin_ns + rel
        mod = sys.modules.get(mod_name)
        if mod is None:
            try:
                mod = importlib.import_module(mod_name)
            except Exception:
                continue
        candidate = getattr(mod, handler_name, None)
        if callable(candidate):
            return candidate
    return None


def has_all_production_tools(mgr: Any, loaded: Any) -> bool:
    """True when both MySQL and SSH tools are registered with production handlers."""
    return _has_our_tool(
        mgr,
        loaded,
        MYSQL_TOOL_NAME,
        "handle_mysql_credential_action",
        (".credential_guard.tools", ".tools"),
    ) and _has_our_tool(
        mgr,
        loaded,
        SSH_TOOL_NAME,
        "handle_ssh_credential_action",
        (".credential_guard.ssh_tools", ".ssh_tools"),
    )


def _has_our_tool(
    mgr: Any,
    loaded: Any,
    tool_name: str,
    handler_name: str,
    rels: tuple,
) -> bool:
    """Require tool registered with the exact production handler callable."""
    expected_handler = _resolve_handler(loaded, handler_name, rels)
    if expected_handler is None:
        return False

    plugin_tools = getattr(mgr, "_plugin_tool_names", None)
    if isinstance(plugin_tools, set) and tool_name not in plugin_tools:
        return False

    try:
        from tools.registry import registry

        entry = registry.get_entry(tool_name)
    except Exception:
        entry = None
    if entry is None:
        # Unit-test FakeMgr without tools.registry: accept explicit attribute.
        tools = getattr(mgr, "_tools", {}) or {}
        handler = tools.get(tool_name)
        return handler is expected_handler
    return getattr(entry, "handler", None) is expected_handler
