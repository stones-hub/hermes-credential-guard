"""ssh_credential_action tool: schema, availability, and handler."""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Set

from .file_backend import FileBackendError, TargetMetadataBackend
from .tools import TOOLSET_NAME, default_store_dir

logger = logging.getLogger("credential_guard")

TOOL_NAME = "ssh_credential_action"
ALLOWED_ACTIONS = ("check_connection", "show_remote_identity")
_ALLOWED_ARG_KEYS: Set[str] = {"target", "action"}

_SAFE = {
    "ok": False,
    "error_code": "tool_failed",
    "message": "credential-guard blocked unsafe tool execution",
}


def ssh_credential_action_schema() -> Dict[str, Any]:
    return {
        "name": TOOL_NAME,
        "description": (
            "Run a fixed SSH Config public-key action against a named local "
            "target. Requires human approval. Never accepts hosts, keys, "
            "passwords, or free-form remote commands."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "Logical SSH target name from targets.json",
                },
                "action": {
                    "type": "string",
                    "enum": list(ALLOWED_ACTIONS),
                    "description": "Fixed SSH action name",
                },
            },
            "required": ["target", "action"],
            "additionalProperties": False,
        },
    }


def check_ssh_credential_action_available() -> bool:
    try:
        store = default_store_dir()
        if not store.is_dir():
            return False
        backend = TargetMetadataBackend(store)
        backend.list_target_metadata()
        return True
    except Exception:
        return False


def _safe_json(error_code: str) -> str:
    payload = dict(_SAFE)
    payload["error_code"] = error_code
    return json.dumps(payload, ensure_ascii=False)


def handle_ssh_credential_action(args: Dict[str, Any], **_kwargs: Any) -> str:
    """Hermes tool handler. Runs only after host approval invokes it."""
    try:
        if not isinstance(args, dict):
            return _safe_json("invalid_args")
        # Strict second-pass validation even if schema was bypassed.
        if set(args) - _ALLOWED_ARG_KEYS:
            return _safe_json("invalid_args")
        target = args.get("target")
        action = args.get("action")
        if not isinstance(target, str) or not target:
            return _safe_json("invalid_target")
        if action not in ALLOWED_ACTIONS:
            return _safe_json("invalid_action")

        backend = TargetMetadataBackend(default_store_dir())
        meta = backend.get_target(target)
        if meta.get("type") != "ssh_config":
            return _safe_json("target_type_mismatch")
        alias = meta.get("ssh_alias")
        if not isinstance(alias, str) or not alias:
            return _safe_json("backend_unavailable")

        from .ssh_executor import execute_ssh_action

        result = execute_ssh_action(str(action), alias)
        if not isinstance(result, dict):
            return _safe_json("executor_failed")
        out = dict(result)
        out.setdefault("target", target)
        out.setdefault("action", action)
        for banned in (
            "password",
            "passwd",
            "secret",
            "ssh_alias",
            "alias",
            "argv",
            "host",
            "hostname",
            "port",
            "identity_file",
            "stderr",
            "stdout",
            "command",
        ):
            out.pop(banned, None)
        return json.dumps(out, ensure_ascii=False)
    except FileBackendError:
        logger.warning("credential-guard ssh tool blocked: backend error")
        return _safe_json("backend_unavailable")
    except Exception:
        logger.warning("credential-guard ssh tool failed closed")
        return _safe_json("tool_failed")
