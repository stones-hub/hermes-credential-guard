"""Fixed-action OpenSSH executor (argv array only; no shell)."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Tuple

ALLOWED_ACTIONS = ("check_connection", "show_remote_identity")
SSH_CONNECT_TIMEOUT = 8
_MAX_OUTPUT_BYTES = 4096
_REMOTE_USER_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_-]{0,31}$")

# Alias charset mirrors file_backend (avoid importing to keep executor lean).
_SSH_ALIAS_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")

_REMOTE_COMMANDS = {
    "check_connection": "true",
    "show_remote_identity": "id -un",
}

_SAFE_OPTIONS: Tuple[str, ...] = (
    "BatchMode=yes",
    "PreferredAuthentications=publickey",
    "PasswordAuthentication=no",
    "KbdInteractiveAuthentication=no",
    "StrictHostKeyChecking=yes",
    "ClearAllForwardings=yes",
    "ForwardAgent=no",
    "PermitLocalCommand=no",
    "RequestTTY=no",
    f"ConnectTimeout={SSH_CONNECT_TIMEOUT}",
    "LogLevel=ERROR",
)


def _validate_alias(alias: str) -> str:
    if not isinstance(alias, str) or not alias:
        raise ValueError("invalid ssh_alias")
    if len(alias) > 64 or alias[0] == "-" or any(ord(c) < 32 for c in alias):
        raise ValueError("invalid ssh_alias")
    if any(c.isspace() for c in alias):
        raise ValueError("invalid ssh_alias")
    if not _SSH_ALIAS_RE.fullmatch(alias):
        raise ValueError("invalid ssh_alias")
    return alias


def _user_ssh_config_path() -> Path:
    """Resolve config via Path.home() so process HOME (incl. E2E) is honored.

    OpenSSH's default ``~/.ssh/config`` lookup may use the passwd database
    home rather than ``$HOME``; passing ``-F`` keeps isolated tests and
    production Hermes HOME overrides consistent without reading the file.
    """
    return Path.home() / ".ssh" / "config"


def build_ssh_argv(ssh_alias: str, action: str) -> List[str]:
    alias = _validate_alias(ssh_alias)
    if action not in _REMOTE_COMMANDS:
        raise ValueError("invalid ssh action")
    remote = _REMOTE_COMMANDS[action]
    argv: List[str] = ["ssh"]
    # Pin config via Path.home() (respects process HOME). Path string only —
    # do not stat/read the file here (avoids touching real ~/.ssh in unit tests).
    argv.extend(["-F", str(_user_ssh_config_path())])
    for opt in _SAFE_OPTIONS:
        argv.extend(["-o", opt])
    argv.append(alias)
    argv.append(remote)
    return argv


def _classify_error(returncode: int, stderr: bytes) -> str:
    text = ""
    try:
        text = stderr.decode("utf-8", errors="replace").lower()
    except Exception:
        text = ""
    if (
        "host key verification failed" in text
        or "remote host identification has changed" in text
        or "someone man-in-the-middle" in text
    ):
        return "host_identity_untrusted"
    if "permission denied" in text or "authentication failed" in text:
        return "ssh_authentication_failed"
    if (
        "timed out" in text
        or "timeout" in text
        or "network is unreachable" in text
        or "no route to host" in text
        or "connection refused" in text
        or "could not resolve" in text
        or "name or service not known" in text
    ):
        return "ssh_unreachable_or_timeout"
    if returncode != 0:
        return "ssh_failed"
    return "ssh_failed"


def _safe_fail(error_code: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error_code": error_code,
        "message": "ssh action failed",
    }


def _truncate(data: bytes) -> bytes:
    if len(data) <= _MAX_OUTPUT_BYTES:
        return data
    return data[:_MAX_OUTPUT_BYTES]


def execute_ssh_action(action: str, ssh_alias: str) -> Dict[str, Any]:
    """Run a fixed SSH action. Return value never includes alias/argv/paths."""
    try:
        argv = build_ssh_argv(ssh_alias, action)
    except ValueError:
        return _safe_fail("invalid_args")

    try:
        proc = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            timeout=SSH_CONNECT_TIMEOUT + 2,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return _safe_fail("ssh_unreachable_or_timeout")
    except Exception:
        return _safe_fail("ssh_failed")

    stdout = _truncate(proc.stdout or b"")
    stderr = _truncate(proc.stderr or b"")

    if proc.returncode != 0:
        return _safe_fail(_classify_error(proc.returncode, stderr))

    if action == "check_connection":
        return {"ok": True, "authenticated": True}

    if action == "show_remote_identity":
        try:
            remote_user = stdout.decode("utf-8", errors="strict").strip()
        except Exception:
            return _safe_fail("ssh_invalid_remote_identity")
        if not _REMOTE_USER_RE.fullmatch(remote_user):
            return _safe_fail("ssh_invalid_remote_identity")
        return {"ok": True, "remote_user": remote_user}

    return _safe_fail("invalid_action")
