"""mysql_credential_action tool: schema, availability, and handler."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

from .file_backend import FileBackendError, FileCredentialBackend
from .targets import TargetBindingError, resolve_mysql_target

logger = logging.getLogger("credential_guard")

TOOL_NAME = "mysql_credential_action"
TOOLSET_NAME = "credential_guard"
ALLOWED_ACTIONS = ("check_connection", "show_effective_grants")

_SAFE = {
    "ok": False,
    "error_code": "tool_failed",
    "message": "credential-guard blocked unsafe tool execution",
}


def mysql_credential_action_schema() -> Dict[str, Any]:
    return {
        "name": TOOL_NAME,
        "description": (
            "Run a fixed read-only MySQL credential action against a named "
            "local target. Requires human approval. Never accepts passwords "
            "or free-form SQL."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "Logical MySQL target name from targets.json",
                },
                "action": {
                    "type": "string",
                    "enum": list(ALLOWED_ACTIONS),
                    "description": "Fixed read-only action name",
                },
            },
            "required": ["target", "action"],
            "additionalProperties": False,
        },
    }


def default_store_dir() -> Path:
    home = os.environ.get("HERMES_HOME", "").strip()
    if home:
        return Path(home) / "credential-guard"
    return Path.home() / ".hermes" / "credential-guard"


def check_mysql_credential_action_available() -> bool:
    try:
        from .file_backend import TargetMetadataBackend

        store = default_store_dir()
        if not store.is_dir():
            return False
        # Availability uses targets.json only — never opens credentials.json.
        backend = TargetMetadataBackend(store)
        backend.list_target_metadata()
        return True
    except Exception:
        return False


def _backend() -> FileCredentialBackend:
    # Full backend (credentials.json) only after host approval invokes handler.
    return FileCredentialBackend(default_store_dir(), metadata_only=False)


def _resolve_secret_for_handler(
    backend: FileCredentialBackend, credential_id: str
) -> Dict[str, str]:
    return backend.resolve_mysql_secret(credential_id)


def _execute_mysql_action(
    *,
    action: str,
    host: str,
    port: int,
    database: str,
    username: str,
    password: str,
) -> Dict[str, Any]:
    from .mysql_executor import execute_action

    return execute_action(
        action=action,
        host=host,
        port=port,
        database=database,
        username=username,
        password=password,
    )


def handle_mysql_credential_action(args: Dict[str, Any], **_kwargs: Any) -> str:
    """Hermes tool handler. Secrets are loaded only after host approval.

    Hermes runs ``pre_tool_call`` → approval gate before invoking this handler.
    """
    try:
        if not isinstance(args, dict):
            return _safe_json("invalid_args")
        target = args.get("target")
        action = args.get("action")
        if not isinstance(target, str) or not target:
            return _safe_json("invalid_target")
        if action not in ALLOWED_ACTIONS:
            return _safe_json("invalid_action")

        backend = _backend()
        bound = resolve_mysql_target(backend, target)
        # Secret load happens HERE — only reachable after Hermes approval.
        secret = _resolve_secret_for_handler(backend, bound["credential_id"])
        result = _execute_mysql_action(
            action=str(action),
            host=str(bound["host"]),
            port=int(bound["port"]),
            database=str(bound["database"]),
            username=str(secret["username"]),
            password=str(secret["password"]),
        )
        # Never include password fields.
        if not isinstance(result, dict):
            return _safe_json("executor_failed")
        result = dict(result)
        result.setdefault("target", bound["target_id"])
        result.setdefault("action", action)
        result.setdefault("credential_id", bound["credential_id"])
        for banned in ("password", "passwd", "secret", "dsn"):
            result.pop(banned, None)
        return json.dumps(result, ensure_ascii=False)
    except (FileBackendError, TargetBindingError):
        logger.warning("credential-guard tool blocked: backend/binding error")
        return _safe_json("backend_unavailable")
    except Exception:
        logger.warning("credential-guard tool failed closed")
        return _safe_json("tool_failed")


def _safe_json(error_code: str) -> str:
    payload = dict(_SAFE)
    payload["error_code"] = error_code
    return json.dumps(payload, ensure_ascii=False)
