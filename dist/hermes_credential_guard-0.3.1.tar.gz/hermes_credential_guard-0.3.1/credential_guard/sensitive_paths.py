"""Sensitive path and private-key content detection (pure helpers)."""

from __future__ import annotations

import base64
import json
import os
import re
from pathlib import Path
from typing import Any, List, Optional, Sequence
from urllib.parse import unquote, unquote_plus

# PEM private-key markers (case-insensitive). Certificates are excluded.
_PRIVATE_KEY_BEGIN = re.compile(
    r"-----BEGIN[^\n-]{0,80}PRIVATE KEY-----",
    re.IGNORECASE,
)
_PRIVATE_KEY_END = re.compile(
    r"-----END[^\n-]{0,80}PRIVATE KEY-----",
    re.IGNORECASE,
)

_READ_PATH_KEYS = ("path", "file_path", "filename", "file")
_SEARCH_PATH_KEYS = ("path", "directory", "root", "dir")
_SEARCH_TOOL_NAMES = frozenset(
    {"search_files", "search", "find_files", "grep_files"}
)
_READ_TOOL_NAMES = frozenset({"read_file", "read", "open_file"})

_PROTECTED_SSH_BASENAMES = frozenset(
    {
        "config",
        "authorized_keys",
        "authorized_keys2",
    }
)
_STORE_BASENAMES = frozenset({"credentials.json", "targets.json"})

# Leading $HOME / ${HOME} / $HERMES_HOME / ${HERMES_HOME} only — no shell.
_CONTROLLED_ENV_PREFIX = re.compile(
    r"^(?P<var>\$\{HOME\}|\$HOME|\$\{HERMES_HOME\}|\$HERMES_HOME)(?P<rest>/.*)?$"
)

# Encoded private-key scan bounds (fail closed when exceeded).
MAX_PRIVATE_KEY_SCAN_BYTES = 512_000
MAX_PRIVATE_KEY_DECODE_CANDIDATES = 64
MAX_PRIVATE_KEY_CANDIDATE_LENGTH = 65_536
MIN_PRIVATE_KEY_B64_CANDIDATE = 48
MIN_PRIVATE_KEY_PERCENT_CANDIDATE = 40

_B64_ALPHABET_RE = re.compile(r"[A-Za-z0-9+/_-]+=*")
_PERCENT_RUN_RE = re.compile(r"(?:%[0-9A-Fa-f]{2}|[A-Za-z0-9\-._~]){" + str(MIN_PRIVATE_KEY_PERCENT_CANDIDATE) + r",}")


class EncodedPrivateKeyScanError(RuntimeError):
    """Raised when encoded private-key scanning exceeds bounds or fails closed."""


def looks_like_private_key(text: str) -> bool:
    if not isinstance(text, str) or not text:
        return False
    if _PRIVATE_KEY_BEGIN.search(text) and _PRIVATE_KEY_END.search(text):
        return True
    # Single-marker high-confidence OpenSSH/RSA/EC/PKCS8 begins.
    if re.search(
        r"-----BEGIN\s+(OPENSSH|RSA|EC|DSA|ENCRYPTED)?\s*PRIVATE KEY-----",
        text,
        re.IGNORECASE,
    ):
        return True
    return False


def _try_b64_decode(candidate: str) -> Optional[str]:
    s = candidate.strip()
    if len(s) < MIN_PRIVATE_KEY_B64_CANDIDATE:
        return None
    if len(s) > MAX_PRIVATE_KEY_CANDIDATE_LENGTH:
        raise EncodedPrivateKeyScanError("candidate exceeds max length")
    # Strict alphabet + padding.
    if not re.fullmatch(r"[A-Za-z0-9+/_-]+={0,2}", s):
        return None
    if len(s) % 4 != 0:
        return None
    try:
        # Prefer alphabet-appropriate decoder.
        # urlsafe_b64decode has no validate=; use altchars for strict URL-safe.
        if "-" in s or "_" in s:
            raw = base64.b64decode(s, altchars=b"-_", validate=True)
        else:
            raw = base64.b64decode(s, validate=True)
    except Exception:
        return None
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _try_percent_decode(candidate: str) -> Optional[str]:
    s = candidate.strip()
    if len(s) < MIN_PRIVATE_KEY_PERCENT_CANDIDATE:
        return None
    if len(s) > MAX_PRIVATE_KEY_CANDIDATE_LENGTH:
        raise EncodedPrivateKeyScanError("candidate exceeds max length")
    if "%" not in s:
        return None
    try:
        a = unquote(s)
        b = unquote_plus(s)
    except Exception:
        return None
    # Prefer the decode that actually changed something.
    for decoded in (a, b):
        if decoded != s and looks_like_private_key(decoded):
            return decoded
    if a != s:
        return a
    if b != s:
        return b
    return None


def _try_json_unescape(candidate: str) -> Optional[str]:
    s = candidate
    if len(s) > MAX_PRIVATE_KEY_CANDIDATE_LENGTH:
        raise EncodedPrivateKeyScanError("candidate exceeds max length")
    if "\\" not in s and "\\u" not in s:
        # Still allow when only quotes escaped... require backslash form.
        if '\\"' not in s and "\\\\" not in s:
            return None
    try:
        decoded = json.loads(f'"{s}"')
    except Exception:
        return None
    if not isinstance(decoded, str) or decoded == s:
        return None
    return decoded


def _iter_decode_candidates(text: str) -> List[str]:
    """Collect whole-string + bounded substring candidates for one-shot decode."""
    candidates: List[str] = []
    seen: set[str] = set()

    def add(item: str) -> None:
        if not item or item in seen:
            return
        if len(item) > MAX_PRIVATE_KEY_CANDIDATE_LENGTH:
            raise EncodedPrivateKeyScanError("candidate exceeds max length")
        seen.add(item)
        candidates.append(item)
        if len(candidates) > MAX_PRIVATE_KEY_DECODE_CANDIDATES:
            raise EncodedPrivateKeyScanError("too many decode candidates")

    add(text.strip())
    for match in _B64_ALPHABET_RE.finditer(text):
        token = match.group(0)
        if len(token) >= MIN_PRIVATE_KEY_B64_CANDIDATE:
            add(token)
    for match in _PERCENT_RUN_RE.finditer(text):
        add(match.group(0))
    # JSON-escape interiors often appear as the whole field content.
    if "\\u" in text or '\\"' in text or "\\\\" in text:
        add(text)
    return candidates


def contains_private_key_material(text: str) -> bool:
    """Authoritative private-key detector for provider/tool boundaries.

    Detects raw PEM and one-shot percent / quote-plus / Base64 / URL-safe Base64
    / JSON-unescape forms. Exceeding scan bounds raises EncodedPrivateKeyScanError
    (callers must fail closed). Does not recurse.
    """
    if not isinstance(text, str) or not text:
        return False
    if len(text.encode("utf-8", errors="surrogatepass")) > MAX_PRIVATE_KEY_SCAN_BYTES:
        raise EncodedPrivateKeyScanError("payload exceeds scan byte limit")
    if looks_like_private_key(text):
        return True

    try:
        candidates = _iter_decode_candidates(text)
    except EncodedPrivateKeyScanError:
        raise
    except Exception as exc:
        raise EncodedPrivateKeyScanError("candidate extraction failed") from exc

    for candidate in candidates:
        try:
            decoded_forms = [
                _try_percent_decode(candidate),
                _try_b64_decode(candidate),
                _try_json_unescape(candidate),
            ]
        except EncodedPrivateKeyScanError:
            raise
        except Exception as exc:
            raise EncodedPrivateKeyScanError("decode attempt failed") from exc
        for decoded in decoded_forms:
            if decoded and looks_like_private_key(decoded):
                return True
    return False


def extract_path_candidates(tool_name: str, args: Any) -> List[str]:
    if not isinstance(args, dict):
        return []
    name = (tool_name or "").strip()
    keys: Sequence[str]
    if name in _READ_TOOL_NAMES:
        keys = _READ_PATH_KEYS
    elif name in _SEARCH_TOOL_NAMES:
        keys = _SEARCH_PATH_KEYS
    else:
        return []
    out: List[str] = []
    for key in keys:
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            out.append(value.strip())
    # Hermes search_files defaults omitted path to "."
    if name in _SEARCH_TOOL_NAMES and not out:
        out.append(".")
    return out


def _strip_wrapping_quotes(raw: str) -> str:
    s = raw.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"":
        return s[1:-1]
    return s


def _expand_controlled_env_prefix(raw: str) -> str:
    """Expand only leading HOME / HERMES_HOME. Never invokes a shell."""
    s = _strip_wrapping_quotes(raw)
    match = _CONTROLLED_ENV_PREFIX.match(s)
    if not match:
        return raw
    token = match.group("var")
    if token in ("$HOME", "${HOME}"):
        env_name = "HOME"
    else:
        env_name = "HERMES_HOME"
    value = os.environ.get(env_name, "").strip()
    if not value:
        # Undefined — do not claim a resolved protected path via this prefix.
        return raw
    rest = match.group("rest") or ""
    return value + rest


def _expand_user(raw: str) -> Path:
    return Path(os.path.expanduser(raw)).expanduser()


def _normalize_path_input(raw: str) -> Path:
    expanded = _expand_controlled_env_prefix(raw.strip())
    return _expand_user(expanded)


def _home_ssh_dir() -> Path:
    return Path.home() / ".ssh"


def _store_dir() -> Path:
    hermes = os.environ.get("HERMES_HOME", "").strip()
    if hermes:
        return Path(hermes) / "credential-guard"
    return Path.home() / ".hermes" / "credential-guard"


def _credentials_json_path() -> Path:
    return _store_dir() / "credentials.json"


def _safe_realpath(path: Path) -> Optional[Path]:
    try:
        if path.exists():
            return Path(os.path.realpath(path))
    except OSError:
        return None
    try:
        # Non-existent: resolve parents best-effort without requiring final file.
        parent = path.parent
        if parent.exists():
            return Path(os.path.realpath(parent)) / path.name
        return path.absolute()
    except OSError:
        return None


def _is_under(child: Path, parent: Path) -> bool:
    try:
        child_r = Path(os.path.realpath(child)) if child.exists() else child.resolve()
        parent_r = Path(os.path.realpath(parent)) if parent.exists() else parent.resolve()
        child_r.relative_to(parent_r)
        return True
    except (OSError, ValueError):
        return False


def _is_protected_known_hosts_name(name: str) -> bool:
    if name == "known_hosts":
        return True
    if not name.startswith("known_hosts."):
        return False
    suffix = name[len("known_hosts.") :]
    # Obvious example files are not protected material.
    if suffix == "example" or suffix.endswith(".example"):
        return False
    return True


def _is_protected_identity_name(name: str) -> bool:
    if not name.startswith("id_"):
        return False
    # Public keys remain readable.
    if name.endswith(".pub"):
        return False
    return True


def _ssh_basename_is_protected(name: str) -> bool:
    if name in _PROTECTED_SSH_BASENAMES:
        return True
    if _is_protected_known_hosts_name(name):
        return True
    if _is_protected_identity_name(name):
        return True
    return False


def _ssh_file_is_protected(path: Path) -> bool:
    """Return True if path is a protected SSH material path."""
    ssh = _home_ssh_dir()
    try:
        name = path.name
    except Exception:
        return False

    # Direct basename rules under ~/.ssh
    under_ssh = _is_under(path, ssh) or _path_looks_like_ssh_child(path, ssh)
    if under_ssh:
        if _ssh_basename_is_protected(name):
            return True
        # ssh_key/** under ~/.ssh
        try:
            rel = _relative_to_ssh(path, ssh)
            if rel is not None:
                parts = rel.parts
                if parts and parts[0] == "ssh_key":
                    # Still allow obvious public keys under ssh_key.
                    if name.endswith(".pub"):
                        return False
                    return True
                if _ssh_basename_is_protected(name):
                    return True
        except Exception:
            return True  # fail closed when uncertain under .ssh
        # Any path under ~/.ssh/ssh_key (except .pub handled above)
        if "ssh_key" in path.parts and not name.endswith(".pub"):
            return True

    # Symlink / realpath landing on protected
    real = _safe_realpath(path)
    if real is not None and real != path:
        return _ssh_file_is_protected(real) or _store_file_is_protected(real)
    return False


def _path_looks_like_ssh_child(path: Path, ssh: Path) -> bool:
    try:
        expanded = _expand_user(str(path))
        parts = expanded.parts
        ssh_parts = ssh.parts
        if len(parts) >= len(ssh_parts) and parts[: len(ssh_parts)] == ssh_parts:
            return True
    except Exception:
        return False
    # String form with ~/.ssh
    raw = str(path)
    if raw.startswith("~/.ssh/") or raw.startswith("~/.ssh"):
        return True
    return False


def _relative_to_ssh(path: Path, ssh: Path) -> Optional[Path]:
    try:
        expanded = _expand_user(str(path))
        if expanded.exists() or ssh.exists():
            try:
                return Path(os.path.realpath(expanded)).relative_to(
                    Path(os.path.realpath(ssh))
                )
            except ValueError:
                pass
        return expanded.resolve(strict=False).relative_to(ssh.resolve(strict=False))
    except (OSError, ValueError):
        return None


def _store_file_is_protected(path: Path) -> bool:
    """Protect Credential Guard local store dual files."""
    store = _store_dir()
    try:
        name = path.name
        check = path
        if name not in _STORE_BASENAMES:
            real = _safe_realpath(path)
            if real is None or real.name not in _STORE_BASENAMES:
                return False
            check = real
            name = real.name
        expected = store / name
        expected_real = _safe_realpath(expected) or expected
        path_real = _safe_realpath(check) or check
        if path_real == expected_real:
            return True
        if Path(os.path.abspath(path_real)) == Path(os.path.abspath(expected_real)):
            return True
    except OSError:
        return False
    return False


def path_is_protected(raw_path: str) -> bool:
    if not isinstance(raw_path, str) or not raw_path.strip():
        return False
    try:
        path = _normalize_path_input(raw_path)
    except Exception:
        return True  # fail closed on weird input
    if _store_file_is_protected(path):
        return True
    if _ssh_file_is_protected(path):
        return True
    # Resolve symlink / .. components when present.
    real = _safe_realpath(path)
    if real is not None:
        if _store_file_is_protected(real):
            return True
        if _ssh_file_is_protected(real):
            return True
    return False


def search_path_is_protected(raw_path: str) -> bool:
    """Fail closed when a search root is or can scan into a protected tree."""
    if not isinstance(raw_path, str) or not raw_path.strip():
        return False
    try:
        root = _normalize_path_input(raw_path)
    except Exception:
        return True
    ssh = _home_ssh_dir()
    store = _store_dir()

    # Searching the protected path itself or anything under it.
    if path_is_protected(str(root)):
        return True
    if _is_under(root, ssh) or _path_looks_like_ssh_child(root, ssh):
        return True
    if root == ssh or str(root).rstrip("/") == str(ssh):
        return True

    # Searching a parent that contains the protected tree → can scan into it.
    try:
        if ssh.exists() and _is_under(ssh, root):
            return True
        # Even if .ssh does not exist yet, searching HOME covers ~/.ssh.
        home = Path.home()
        if _is_under(home, root) or root == home:
            return True
        if _path_looks_like_ssh_child(root, ssh):
            return True
        if store.exists() and _is_under(store, root):
            return True
        if root == store or _is_under(root, store):
            return True
    except OSError:
        return True
    return False


def args_target_protected(tool_name: str, args: Any) -> bool:
    name = (tool_name or "").strip()
    candidates = extract_path_candidates(name, args)
    if name in _SEARCH_TOOL_NAMES:
        return any(search_path_is_protected(c) for c in candidates)
    return any(path_is_protected(c) for c in candidates)


_DIRECT_READ_RE = re.compile(
    r"(?i)(?:^|[;&|`\n]|&&|\|\|)\s*(?:"
    r"cat|head|tail|less|more|nl|od|hexdump|xxd|bat|view|vim|vi|emacs|nano|"
    r"type|Get-Content"
    r")\s+(?P<path>[^\s;|&]+)"
)


def terminal_command_reads_protected(command: str) -> bool:
    """Block only clearly direct reads of protected paths (honest boundary)."""
    if not isinstance(command, str) or not command.strip():
        return False
    for match in _DIRECT_READ_RE.finditer(command):
        raw = match.group("path").strip("'\"")
        if path_is_protected(raw):
            return True
    # Explicit path tokens that are protected absolute/~ paths.
    for token in re.findall(r"(~/\.ssh/\S+|/(?:Users|home)/\S+/\.ssh/\S+)", command):
        cleaned = token.strip("'\"")
        if path_is_protected(cleaned):
            return True
    # Store dual-file absolute / env-expanded references
    for token in re.findall(r"(\S*(?:credentials|targets)\.json)", command):
        if path_is_protected(token.strip("'\"")):
            return True
    return False
