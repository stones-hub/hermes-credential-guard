"""Secure local JSON credential/target store (metadata-only by default)."""

from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from .registry import validate_identifier

CREDENTIALS_FILENAME = "credentials.json"
TARGETS_FILENAME = "targets.json"
SUPPORTED_VERSION = 1
ALLOWED_CREDENTIAL_TYPES = frozenset({"mysql"})
ALLOWED_TARGET_TYPES = frozenset({"mysql", "ssh_config"})
_CREDENTIAL_FIELDS = frozenset({"type", "username", "password"})
_MYSQL_TARGET_FIELDS = frozenset(
    {"type", "host", "port", "database", "credential_ref"}
)
_SSH_TARGET_FIELDS = frozenset({"type", "ssh_alias"})
# Conservative Host-alias charset: no leading dash, no wildcards, no whitespace.
_SSH_ALIAS_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
_SSH_ALIAS_MAX_LEN = 64


class FileBackendError(Exception):
    """Fail-closed backend error. Message must never embed secrets."""


@dataclass(frozen=True)
class _OpenFile:
    fd: int
    path: Path

    def close(self) -> None:
        try:
            os.close(self.fd)
        except OSError:
            pass


def _mode_bits(mode: int) -> int:
    return stat.S_IMODE(mode)


def _open_nofollow(path: Path, flags: int) -> int:
    """Open path without following the final symlink component when possible."""
    open_flags = flags | getattr(os, "O_CLOEXEC", 0)
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    if nofollow:
        try:
            return os.open(path, open_flags | nofollow)
        except OSError as exc:
            # ELOOP / EMLINK-style: symlink final component.
            raise FileBackendError("path must not be a symbolic link") from exc
    # Platforms without O_NOFOLLOW: reject symlinks via lstat before open,
    # then re-check with fstat after open (best-effort TOCTOU mitigation).
    try:
        st = path.lstat()
    except OSError as exc:
        raise FileBackendError("unable to open credential store path") from exc
    if stat.S_ISLNK(st.st_mode):
        raise FileBackendError("path must not be a symbolic link")
    return os.open(path, open_flags)


def _assert_secure_dir(path: Path) -> None:
    try:
        st = path.lstat()
    except OSError as exc:
        raise FileBackendError("credential store directory unavailable") from exc
    if stat.S_ISLNK(st.st_mode):
        raise FileBackendError("credential store directory must not be a symlink")
    if not stat.S_ISDIR(st.st_mode):
        raise FileBackendError("credential store path must be a directory")
    if _mode_bits(st.st_mode) != 0o700:
        raise FileBackendError("credential store directory mode must be 0700")
    if st.st_uid != os.geteuid():
        raise FileBackendError("credential store directory owner mismatch")


def _assert_secure_regular_file(fd: int, path: Path) -> None:
    try:
        st = os.fstat(fd)
    except OSError as exc:
        raise FileBackendError("unable to stat credential file") from exc
    if not stat.S_ISREG(st.st_mode):
        raise FileBackendError("credential store entry must be a regular file")
    # Detect if the path itself is a symlink (even if O_NOFOLLOW unavailable
    # and open followed it — reject when lstat says symlink).
    try:
        lst = path.lstat()
    except OSError as exc:
        raise FileBackendError("unable to lstat credential file") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise FileBackendError("credential file must not be a symbolic link")
    if _mode_bits(st.st_mode) != 0o600:
        raise FileBackendError("credential file mode must be 0600")
    if st.st_uid != os.geteuid():
        raise FileBackendError("credential file owner mismatch")


def _read_json_file(path: Path) -> Any:
    fd = _open_nofollow(path, os.O_RDONLY)
    try:
        _assert_secure_regular_file(fd, path)
        chunks: List[bytes] = []
        while True:
            block = os.read(fd, 65536)
            if not block:
                break
            chunks.append(block)
        raw = b"".join(chunks)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise FileBackendError("credential store is not valid UTF-8") from exc
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise FileBackendError("credential store JSON is invalid") from exc


def _require_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise FileBackendError(f"{label} must be an object")
    return value


def _validate_credential_entry(cred_id: str, entry: Any) -> Dict[str, str]:
    validate_identifier(cred_id, "key")
    data = _require_mapping(entry, "credential entry")
    unknown = set(data) - _CREDENTIAL_FIELDS
    if unknown:
        raise FileBackendError("credential entry has unknown fields")
    missing = _CREDENTIAL_FIELDS - set(data)
    if missing:
        raise FileBackendError("credential entry missing required fields")
    ctype = data["type"]
    if ctype not in ALLOWED_CREDENTIAL_TYPES:
        raise FileBackendError("unsupported credential type")
    username = data["username"]
    password = data["password"]
    if not isinstance(username, str) or not username:
        raise FileBackendError("invalid credential username")
    if not isinstance(password, str) or not password:
        raise FileBackendError("invalid credential secret")
    if any(ord(ch) < 32 for ch in username):
        raise FileBackendError("invalid credential username")
    if any(ord(ch) < 32 for ch in password):
        raise FileBackendError("invalid credential secret")
    return {
        "id": cred_id,
        "type": str(ctype),
        "username": username,
        "password": password,
    }


def _validate_ssh_alias(alias: Any) -> str:
    if not isinstance(alias, str) or not alias:
        raise FileBackendError("invalid ssh_alias")
    if len(alias) > _SSH_ALIAS_MAX_LEN:
        raise FileBackendError("invalid ssh_alias")
    if any(ord(ch) < 32 for ch in alias):
        raise FileBackendError("invalid ssh_alias")
    if alias[0] == "-":
        raise FileBackendError("invalid ssh_alias")
    if any(ch.isspace() for ch in alias):
        raise FileBackendError("invalid ssh_alias")
    if any(ch in alias for ch in "*?%;&|'\"`/\\:@$(){}[]<>"):
        raise FileBackendError("invalid ssh_alias")
    if not _SSH_ALIAS_RE.fullmatch(alias):
        raise FileBackendError("invalid ssh_alias")
    return alias


def _validate_mysql_target(target_id: str, data: Mapping[str, Any]) -> Dict[str, Any]:
    unknown = set(data) - _MYSQL_TARGET_FIELDS
    if unknown:
        raise FileBackendError("target entry has unknown fields")
    missing = _MYSQL_TARGET_FIELDS - set(data)
    if missing:
        raise FileBackendError("target entry missing required fields")
    host = data["host"]
    port = data["port"]
    database = data["database"]
    credential_ref = data["credential_ref"]
    if not isinstance(host, str) or not host:
        raise FileBackendError("invalid target host")
    if not isinstance(port, int) or isinstance(port, bool) or not (1 <= port <= 65535):
        raise FileBackendError("invalid target port")
    if not isinstance(database, str) or not database:
        raise FileBackendError("invalid target database")
    if not isinstance(credential_ref, str) or not credential_ref:
        raise FileBackendError("invalid credential_ref")
    validate_identifier(credential_ref, "key")
    return {
        "id": target_id,
        "type": "mysql",
        "host": host,
        "port": port,
        "database": database,
        "credential_ref": credential_ref,
    }


def _validate_ssh_target(target_id: str, data: Mapping[str, Any]) -> Dict[str, Any]:
    unknown = set(data) - _SSH_TARGET_FIELDS
    if unknown:
        raise FileBackendError("target entry has unknown fields")
    missing = _SSH_TARGET_FIELDS - set(data)
    if missing:
        raise FileBackendError("target entry missing required fields")
    alias = _validate_ssh_alias(data["ssh_alias"])
    return {
        "id": target_id,
        "type": "ssh_config",
        "ssh_alias": alias,
    }


def _validate_target_entry(target_id: str, entry: Any) -> Dict[str, Any]:
    if not isinstance(target_id, str) or not target_id:
        raise FileBackendError("invalid target id")
    if any(ord(ch) < 32 for ch in target_id):
        raise FileBackendError("invalid target id")
    data = _require_mapping(entry, "target entry")
    ttype = data.get("type")
    if ttype not in ALLOWED_TARGET_TYPES:
        raise FileBackendError("unsupported target type")
    if ttype == "mysql":
        return _validate_mysql_target(target_id, data)
    if ttype == "ssh_config":
        return _validate_ssh_target(target_id, data)
    raise FileBackendError("unsupported target type")


def _public_target_metadata(item: Mapping[str, Any]) -> Dict[str, Any]:
    """Non-secret target metadata. Shape depends on target type."""
    ttype = item["type"]
    if ttype == "ssh_config":
        return {
            "id": item["id"],
            "type": "ssh_config",
            "ssh_alias": item["ssh_alias"],
        }
    return {
        "id": item["id"],
        "type": item["type"],
        "host": item["host"],
        "port": item["port"],
        "database": item["database"],
        "credential_ref": item["credential_ref"],
    }


def _load_targets_document(store_dir: Path) -> Dict[str, Dict[str, Any]]:
    """Read and validate targets.json only. Never opens credentials.json."""
    _assert_secure_dir(store_dir)
    tgt_raw = _read_json_file(store_dir / TARGETS_FILENAME)
    tgt_doc = _require_mapping(tgt_raw, "targets document")
    if tgt_doc.get("version") != SUPPORTED_VERSION:
        raise FileBackendError("unsupported targets version")
    if set(tgt_doc) - {"version", "targets"}:
        raise FileBackendError("targets document has unknown fields")
    tgt_map = _require_mapping(tgt_doc.get("targets"), "targets")
    targets: Dict[str, Dict[str, Any]] = {}
    for tid, entry in tgt_map.items():
        if not isinstance(tid, str):
            raise FileBackendError("invalid target id")
        targets[tid] = _validate_target_entry(tid, entry)
    return targets


def _load_credentials_document(store_dir: Path) -> Dict[str, Dict[str, str]]:
    """Read and validate credentials.json (egress snapshot or post-approval)."""
    _assert_secure_dir(store_dir)
    cred_raw = _read_json_file(store_dir / CREDENTIALS_FILENAME)
    cred_doc = _require_mapping(cred_raw, "credentials document")
    if cred_doc.get("version") != SUPPORTED_VERSION:
        raise FileBackendError("unsupported credentials version")
    if set(cred_doc) - {"version", "credentials"}:
        raise FileBackendError("credentials document has unknown fields")
    cred_map = _require_mapping(cred_doc.get("credentials"), "credentials")
    credentials: Dict[str, Dict[str, str]] = {}
    for cid, entry in cred_map.items():
        if not isinstance(cid, str):
            raise FileBackendError("invalid credential id")
        credentials[cid] = _validate_credential_entry(cid, entry)
    return credentials


def build_redaction_registry_snapshot(
    store_dir: Path | str | None = None,
) -> "CredentialRegistry":
    """Read credentials.json and build a fresh in-memory redaction registry.

    Returns only a memory snapshot. Never logs, prints, or returns secrets.
    Any permission/schema/registry failure raises FileBackendError (fail closed).
    """
    from .registry import CredentialRegistry

    if store_dir is None:
        from .tools import default_store_dir

        root = default_store_dir()
    else:
        root = Path(store_dir)
    try:
        credentials = _load_credentials_document(root)
    except FileBackendError:
        raise
    except Exception as exc:
        raise FileBackendError("credential store unavailable") from exc

    registry = CredentialRegistry()
    # Stable insertion order by credential id for deterministic conflicts.
    for cid in sorted(credentials):
        item = credentials[cid]
        try:
            # Identity is credential id + fixed field — never username alone (no leak).
            registry.register(cid, "password", item["password"])
            # Egress-only Basic Auth combination (username:password) + its encodings.
            combo = f"{item['username']}:{item['password']}"
            registry.register(cid, "basic_auth", combo)
        except ValueError as exc:
            raise FileBackendError("egress registry registration failed") from exc
        except Exception as exc:
            raise FileBackendError("egress registry registration failed") from exc
    return registry


class TargetMetadataBackend:
    """Read-only targets.json metadata. Never opens credentials.json."""

    def __init__(self, store_dir: Path | str) -> None:
        self._store_dir = Path(store_dir)
        self._targets: Optional[Dict[str, Dict[str, Any]]] = None
        self._load_error: Optional[str] = None
        try:
            self._targets = _load_targets_document(self._store_dir)
            self._load_error = None
        except FileBackendError as exc:
            self._targets = None
            self._load_error = str(exc) or "backend unavailable"
        except Exception:
            self._targets = None
            self._load_error = "backend unavailable"

    def _require_ready(self) -> Dict[str, Dict[str, Any]]:
        if self._targets is None:
            raise FileBackendError(self._load_error or "backend unavailable")
        return self._targets

    def list_target_metadata(self) -> List[Dict[str, Any]]:
        targets = self._require_ready()
        out: List[Dict[str, Any]] = []
        for tid in sorted(targets):
            out.append(_public_target_metadata(targets[tid]))
        return out

    def get_target(self, target_id: str) -> Dict[str, Any]:
        targets = self._require_ready()
        item = targets.get(target_id)
        if item is None:
            raise FileBackendError("unknown target")
        return _public_target_metadata(item)


class FileCredentialBackend:
    """Local JSON backend.

    ``metadata_only=True`` loads only targets.json (safe for approval text).
    Full mode loads both files; use only after human approval when secrets
    are required.
    """

    def __init__(
        self, store_dir: Path | str, *, metadata_only: bool = False
    ) -> None:
        self._store_dir = Path(store_dir)
        self._metadata_only = bool(metadata_only)
        self._credentials: Optional[Dict[str, Dict[str, str]]] = None
        self._targets: Optional[Dict[str, Dict[str, Any]]] = None
        self._load_error: Optional[str] = None
        self._load()

    def _mark_unusable(self, message: str) -> None:
        self._credentials = None
        self._targets = None
        self._load_error = message

    def _load(self) -> None:
        try:
            self._targets = _load_targets_document(self._store_dir)
            if self._metadata_only:
                self._credentials = None
                self._load_error = None
                return
            self._credentials = _load_credentials_document(self._store_dir)
            self._load_error = None
        except FileBackendError as exc:
            self._mark_unusable(str(exc) or "backend unavailable")
        except Exception:
            self._mark_unusable("backend unavailable")

    def _require_targets(self) -> Dict[str, Dict[str, Any]]:
        if self._targets is None:
            raise FileBackendError(self._load_error or "backend unavailable")
        return self._targets

    def _require_credentials(self) -> Dict[str, Dict[str, str]]:
        if self._metadata_only:
            raise FileBackendError("credentials unavailable in metadata-only mode")
        if self._credentials is None:
            raise FileBackendError(self._load_error or "backend unavailable")
        return self._credentials

    def _require_ready(self) -> Tuple[Dict[str, Dict[str, str]], Dict[str, Dict[str, Any]]]:
        return self._require_credentials(), self._require_targets()

    def list_credential_metadata(self) -> List[Dict[str, str]]:
        credentials = self._require_credentials()
        out: List[Dict[str, str]] = []
        for cid in sorted(credentials):
            item = credentials[cid]
            out.append(
                {
                    "id": item["id"],
                    "type": item["type"],
                    "username": item["username"],
                }
            )
        return out

    def list_target_metadata(self) -> List[Dict[str, Any]]:
        targets = self._require_targets()
        out: List[Dict[str, Any]] = []
        for tid in sorted(targets):
            out.append(_public_target_metadata(targets[tid]))
        return out

    def get_target(self, target_id: str) -> Dict[str, Any]:
        targets = self._require_targets()
        item = targets.get(target_id)
        if item is None:
            raise FileBackendError("unknown target")
        return _public_target_metadata(item)

    def resolve_mysql_secret(self, credential_id: str) -> Dict[str, str]:
        """Short-lived secret resolution. Caller must not log the password."""
        credentials = self._require_credentials()
        item = credentials.get(credential_id)
        if item is None:
            raise FileBackendError("unknown credential")
        if item["type"] != "mysql":
            raise FileBackendError("credential type mismatch")
        return {
            "id": item["id"],
            "type": item["type"],
            "username": item["username"],
            "password": item["password"],
        }
