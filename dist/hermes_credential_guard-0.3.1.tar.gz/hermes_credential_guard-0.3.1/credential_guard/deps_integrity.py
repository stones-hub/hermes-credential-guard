"""Vendored dependency integrity checks (PyMySQL pin + RECORD closed-set)."""

from __future__ import annotations

import base64
import hashlib
import re
import stat
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

PINNED_PYMYSQL_VERSION = "1.2.0"
_HASH_RE = re.compile(r"^sha256=(.+)$")


class DepsIntegrityError(Exception):
    """Fail-loud integrity failure. Messages must not embed secrets."""


def _plugin_root() -> Path:
    return Path(__file__).resolve().parent.parent


def deps_dir(root: Path | None = None) -> Path:
    return (root or _plugin_root()) / "deps"


def _urlsafe_b64_sha256(data: bytes) -> str:
    digest = hashlib.sha256(data).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def _parse_record_line(line: str) -> Tuple[str, str | None, int | None]:
    parts = line.split(",")
    if len(parts) < 1 or not parts[0]:
        raise DepsIntegrityError("invalid RECORD line")
    path = parts[0]
    hash_part = parts[1] if len(parts) > 1 else ""
    size_part = parts[2] if len(parts) > 2 else ""
    file_hash = None
    size = None
    if hash_part:
        match = _HASH_RE.match(hash_part)
        if not match:
            raise DepsIntegrityError("invalid RECORD hash")
        file_hash = match.group(1)
    if size_part:
        try:
            size = int(size_part)
        except ValueError as exc:
            raise DepsIntegrityError("invalid RECORD size") from exc
    return path, file_hash, size


def _find_dist_infos(deps: Path) -> List[Path]:
    return sorted(p for p in deps.glob("pymysql-*.dist-info") if p.is_dir())


def expected_pymysql_version_from_requirements(root: Path | None = None) -> str:
    text = ((root or _plugin_root()) / "requirements.txt").read_text(encoding="utf-8")
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("PyMySQL=="):
            return line.split("==", 1)[1].strip()
    raise DepsIntegrityError("requirements.txt missing PyMySQL== pin")


def _is_runtime_file(path: Path) -> bool:
    """Runtime source or executable data under the vendored tree."""
    if path.suffix == ".py":
        return True
    try:
        mode = path.stat().st_mode
    except OSError as exc:
        raise DepsIntegrityError("cannot stat deps file") from exc
    return bool(mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))


def validate_vendored_pymysql(root: Path | None = None) -> Dict[str, Any]:
    """Validate vendored tree: single dist-info, version pin, RECORD closed-set.

    Every runtime file under deps/pymysql/ and hashed dist-info metadata files
    must appear in RECORD with matching size+sha256. Extra .py / executable
    files not listed in RECORD, missing RECORD rows, multiple dist-info dirs,
    or version drift all fail loud.
    """
    base = root or _plugin_root()
    deps = deps_dir(base)
    if not deps.is_dir():
        raise DepsIntegrityError("deps directory missing")
    pymysql_pkg = deps / "pymysql"
    if not (pymysql_pkg / "__init__.py").is_file():
        raise DepsIntegrityError("vendored pymysql package missing")

    req_version = expected_pymysql_version_from_requirements(base)
    if req_version != PINNED_PYMYSQL_VERSION:
        raise DepsIntegrityError("requirements version mismatch")

    dist_infos = _find_dist_infos(deps)
    if len(dist_infos) != 1:
        raise DepsIntegrityError("expected exactly one pymysql dist-info")
    dist = dist_infos[0]
    if dist.name != f"pymysql-{PINNED_PYMYSQL_VERSION}.dist-info":
        raise DepsIntegrityError("dist-info version mismatch")

    meta = (dist / "METADATA").read_text(encoding="utf-8")
    meta_version = None
    for line in meta.splitlines():
        if line.startswith("Version:"):
            meta_version = line.split(":", 1)[1].strip()
            break
    if meta_version != PINNED_PYMYSQL_VERSION:
        raise DepsIntegrityError("METADATA version mismatch")

    record_path = dist / "RECORD"
    if not record_path.is_file():
        raise DepsIntegrityError("RECORD missing")

    hashed_entries: Dict[str, Tuple[str, int]] = {}
    listed_paths: Set[str] = set()
    for raw in record_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        path, file_hash, size = _parse_record_line(line)
        # Skip absolute/cache junk rows (pip install leftovers).
        if path.startswith("..") or path.startswith("/"):
            continue
        listed_paths.add(path)
        if file_hash is None:
            continue
        if size is None:
            raise DepsIntegrityError("RECORD hashed entry missing size")
        hashed_entries[path] = (file_hash, size)

    if not hashed_entries:
        raise DepsIntegrityError("RECORD has no hashed entries")

    verified = 0
    for rel, (expected_hash, expected_size) in sorted(hashed_entries.items()):
        target = deps / rel
        if not target.is_file():
            raise DepsIntegrityError("RECORD path missing")
        data = target.read_bytes()
        if len(data) != expected_size:
            raise DepsIntegrityError("RECORD size mismatch")
        actual = _urlsafe_b64_sha256(data)
        if actual != expected_hash:
            raise DepsIntegrityError("RECORD hash mismatch")
        verified += 1

    # Closed-set: every runtime file under pymysql/ must be listed in RECORD.
    for path in pymysql_pkg.rglob("*"):
        if not path.is_file():
            continue
        if not _is_runtime_file(path):
            continue
        rel = path.relative_to(deps).as_posix()
        if rel not in listed_paths:
            raise DepsIntegrityError("unlisted runtime file in pymysql package")
        if rel not in hashed_entries:
            raise DepsIntegrityError("pymysql runtime file missing RECORD hash")

    # Dist-info metadata files that exist on disk must be consistent.
    for path in dist.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(deps).as_posix()
        if path.name == "RECORD":
            continue
        if rel not in listed_paths:
            raise DepsIntegrityError("unlisted dist-info file")
        if rel in hashed_entries:
            # Already verified above.
            continue
        # Non-hashed RECORD self-row is OK; other metadata should be hashed.
        if path.name != "RECORD":
            # Allow empty REQUESTED etc. only when RECORD lists them (possibly
            # without hash). Presence without hash is accepted for dist-info
            # marker files, but executable extras are not.
            if _is_runtime_file(path) and path.suffix == ".py":
                raise DepsIntegrityError("unexpected python in dist-info")

    # Detect unexpected executable Python sources outside pymysql + dist-info.
    allowed_roots = {pymysql_pkg.resolve(), dist.resolve()}
    for path in deps.rglob("*"):
        if not path.is_file():
            continue
        resolved = path.resolve()
        if any(
            root == resolved or root in resolved.parents for root in allowed_roots
        ):
            continue
        # Non-package markers (.gitignore) are fine; runtime/executables are not.
        if path.suffix == ".py" or _is_runtime_file(path):
            raise DepsIntegrityError("unexpected runtime file in deps")

    manifest = vendored_tree_manifest_sha256(deps)
    return {
        "ok": True,
        "version": PINNED_PYMYSQL_VERSION,
        "verified_files": verified,
        "dist_info": dist.name,
        "manifest_sha256": manifest,
        "deps_dir": str(deps),
    }


def vendored_tree_manifest_sha256(deps: Path | None = None) -> str:
    """Stable SHA-256 over relative path + content digest for deps tree."""
    root = deps or deps_dir()
    lines: List[str] = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{rel}:{digest}")
    blob = "\n".join(lines).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()
