from __future__ import annotations

from .approval import on_pre_tool_call
from .cli import handle_command, setup_parser
from .hooks import on_transform_tool_result
from .middleware import on_llm_execution, on_llm_request
from .ssh_tools import (
    check_ssh_credential_action_available,
    handle_ssh_credential_action,
    ssh_credential_action_schema,
)
from .tools import (
    TOOLSET_NAME,
    check_mysql_credential_action_available,
    handle_mysql_credential_action,
    mysql_credential_action_schema,
)


def register(ctx) -> None:
    ctx.register_middleware("llm_request", on_llm_request)
    ctx.register_middleware("llm_execution", on_llm_execution)
    ctx.register_hook("transform_tool_result", on_transform_tool_result)
    ctx.register_hook("pre_tool_call", on_pre_tool_call)
    ctx.register_tool(
        name="mysql_credential_action",
        toolset=TOOLSET_NAME,
        schema=mysql_credential_action_schema(),
        handler=handle_mysql_credential_action,
        check_fn=check_mysql_credential_action_available,
        description=mysql_credential_action_schema()["description"],
    )
    ctx.register_tool(
        name="ssh_credential_action",
        toolset=TOOLSET_NAME,
        schema=ssh_credential_action_schema(),
        handler=handle_ssh_credential_action,
        check_fn=check_ssh_credential_action_available,
        description=ssh_credential_action_schema()["description"],
    )
    ctx.register_cli_command(
        name="credential-guard",
        help="credential-guard operations",
        setup_fn=setup_parser,
        handler_fn=handle_command,
    )
