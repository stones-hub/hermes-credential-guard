from __future__ import annotations

import json
import logging
from typing import Any

from .redactor import redact_payload, redact_text
from .sensitive_paths import (
    args_target_protected,
    contains_private_key_material,
    terminal_command_reads_protected,
)
from .state import get_egress_registry_snapshot

logger = logging.getLogger("credential_guard")

_SAFE_TOOL_RESULT = json.dumps(
    {"error": "tool result blocked by credential-guard"},
    ensure_ascii=False,
)

_TERMINAL_TOOLS = frozenset({"terminal", "execute_code", "run_terminal_command"})


def on_transform_tool_result(**kwargs: Any) -> str:
    try:
        result = kwargs.get("result", "")
        tool_name = kwargs.get("tool_name", "") or kwargs.get("name", "")
        args = kwargs.get("args") or kwargs.get("arguments") or {}
        if not isinstance(result, str):
            result = str(result)

        # Secondary protection: protected-path tool results never reach the model.
        if isinstance(tool_name, str) and isinstance(args, dict):
            if args_target_protected(tool_name, args):
                return _SAFE_TOOL_RESULT
            name = tool_name.strip()
            if name in _TERMINAL_TOOLS:
                command = ""
                if isinstance(args.get("command"), str):
                    command = args["command"]
                elif isinstance(args.get("code"), str):
                    command = args["code"]
                if command and terminal_command_reads_protected(command):
                    return _SAFE_TOOL_RESULT

        if contains_private_key_material(result):
            return _SAFE_TOOL_RESULT

        registry = get_egress_registry_snapshot()
        stripped = result.strip()
        if stripped.startswith("{") or stripped.startswith("["):
            payload = json.loads(result)
            redacted = redact_payload(payload, registry)
            serialized = json.dumps(redacted, ensure_ascii=False)
            if contains_private_key_material(serialized):
                return _SAFE_TOOL_RESULT
            return serialized
        redacted_text = redact_text(result, registry)
        if contains_private_key_material(redacted_text):
            return _SAFE_TOOL_RESULT
        return redacted_text
    except Exception:
        # Never log exception objects — they may embed decoy/secret text.
        logger.warning("credential-guard failed closed at transform_tool_result")
        return _SAFE_TOOL_RESULT
